import os
cmd='pyhton MyTrain.py'
os.system(cmd)
cmd='pyhton MyTest.py'
os.system(cmd)
cmd='pyhton showing.py'
os.system(cmd)