python -m reproduction_utils.token_check
python -m reproduction_utils.forward_ppg_check