python3 official_tydi/tydi_eval.py \
  --gold_path=data/tydi/tydiqa-v1.0-dev.jsonl.gz \
  --predictions_path=data/tydiqa_baseline_model/predict/pred.jsonl