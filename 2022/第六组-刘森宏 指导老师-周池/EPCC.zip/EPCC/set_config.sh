#!/usr/bin/env bash

NAME=$1

cp $NAME Makefile.defs
echo "Copied $NAME to Makefile.defs"

