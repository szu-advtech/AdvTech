void refer();
void testfirstprivnew();
void testprivnew();
void testcopyprivnew();
void testthrprivnew();
void stats(double*, double*);
