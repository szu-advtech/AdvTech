      integer            colidx(nzz), rowstr(naa+1)
      include 'cgarrays.h'
