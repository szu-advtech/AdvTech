/* Prototype for dummy functions */
extern int omp_get_num_threads();
extern int omp_get_thread_num();
extern int omp_get_max_threads();
