#define CLASS 'A'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "11 Nov 2022"
#define NPBVERSION "3.0"
#define CC "gcc"
#define CFLAGS "-O3 -fopenmp"
#define CLINK "$(CC)"
#define CLINKFLAGS "$(CFLAGS)"
#define C_LIB "-lm"
#define C_INC "(none)"
