# Copyright (c) 2020 Aalto University. All rights reserved.

class SolutionInstance:
    def __init__(self, objVal, X, Y, W, H, solNo):
        self.X = X
        self.Y = Y
        self.W = W
        self.H = H
        self.objVal = objVal
        self.solNo = solNo
