# Copyright (c) 2020 Aalto University. All rights reserved.

TOP_LABEL_NAME = "TOP"
BOTTOM_LABEL_NAME = "BOTTOM"
LEFT_LABEL_NAME = "LEFT"
RIGHT_LABEL_NAME = "RIGHT"
FLEXIBILITY_VALUE = 0.4
OUTPUT_DIR = "results/"
