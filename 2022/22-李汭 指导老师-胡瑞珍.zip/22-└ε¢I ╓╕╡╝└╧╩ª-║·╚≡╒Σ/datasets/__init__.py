from .datasets import Blender, Multicam
dataset_dict = {
    'blender': Blender,
    'multi_blender': Multicam}
