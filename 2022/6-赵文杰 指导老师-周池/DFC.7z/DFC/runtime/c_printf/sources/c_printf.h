#ifndef C_PRINTF
#define C_PRINTF
#include <stdarg.h>

// Simple as we want
int c_printf(const char*, ...);

#endif
