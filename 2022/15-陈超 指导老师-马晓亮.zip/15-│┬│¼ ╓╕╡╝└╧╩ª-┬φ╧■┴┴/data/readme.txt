数据在bb的data文件夹下，通过下面的链接也可直接下载。将对应的数据放在该文件夹下即可。
creditcard.csv: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud/download?datasetVersionNumber=3
kddcup.data: https://archive.ics.uci.edu/ml/machine-learning-databases/kddcup99-mld/kddcup.data.gz
PS_20174392719_1491204439457_log.csv: https://www.kaggle.com/datasets/ealaxi/paysim1/download?datasetVersionNumber=2