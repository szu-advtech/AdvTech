import  numpy as np
from  PIL import  Image
img = Image.open('/data/wzz/MoNuSAC/train/mask_crop/TCGA-5P-A9K0-01Z-00-DX1_2_2.png')
data = np.array(img)
labels = np.unique(data)
counting = { l.item() : np.sum(l==data) for l in labels}
print(counting)
# import torch
# a = torch.rand((2,4,320,320))
# b = torch.ones((2,320,320),dtype=torch.long)
# c = a.gather(index=b.unsqueeze(1),dim=1)
# print(c)
# # import  torch
# a = torch.tensor([[1,2,3,4,5,6],[1,2,3,4,7,8]])
# b = torch.tensor([1,2]).unsqueeze(0)
# print(a.eq(b))
# # for i in b:
# #     index = np.equal(a,i)
# #     a[index] = 255
# #
# # print(a)