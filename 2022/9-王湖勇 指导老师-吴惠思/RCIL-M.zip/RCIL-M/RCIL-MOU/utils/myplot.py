import matplotlib.pyplot as plt
import numpy as np

def plot_bar(index_list,val_dict,epoch):
    color = ['grey', 'red', 'blue', 'green', 'yellow']
    index_list = index_list
    val_dict = val_dict
    # shops = ["A", "B", "C", "D", "E", "F"]
    # sales_product_1 = [100, 85, 56, 42, 72, 15]
    # sales_product_2 = [50, 120, 65, 85, 25, 55]
    # sales_product_3 = [20, 35, 45, 27, 55, 65]

    # 创建分组柱状图，需要自己控制x轴坐标
    # xticks = np.arange(len(shops))

    xticks = np.arange(len(index_list))

    fig, ax = plt.subplots(figsize=(10, 7))
    # 注意控制柱子的宽度，这里选择0.25
    i = 1
    for label, val in val_dict.items():

        ax.bar(xticks,val, width=0.25 * i, label=label, color=color[i-1])
        i = i + 1

    ax.set_title("Grouped Bar plot", fontsize=15)
    ax.set_xlabel("Class")
    ax.set_ylabel("Pixel Number")
    ax.legend()

    # 最后调整x轴标签的位置
    ax.set_xticks(xticks + 0.25)
    ax.set_xticklabels(index_list)
    plt.savefig(f"./data_scripts/class_number_{epoch}.png")
    plt.pause(1)