import logging

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def get_loss(loss_type):
    if loss_type == 'focal_loss':
        return FocalLoss(ignore_index=255, size_average=True)
    elif loss_type == 'cross_entropy':
        return nn.CrossEntropyLoss(ignore_index=255, reduction='mean')


def soft_crossentropy(logits, labels, logits_old, mask_valid_pseudo,
                      mask_background, pseudo_soft, pseudo_soft_factor=1.0):
    if pseudo_soft not in ("soft_certain", "soft_uncertain"):
        raise ValueError(f"Invalid pseudo_soft={pseudo_soft}")
    nb_old_classes = logits_old.shape[1]
    bs, nb_new_classes, w, h = logits.shape

    loss_certain = F.cross_entropy(logits, labels, reduction="none", ignore_index=255)
    loss_uncertain = (torch.log_softmax(logits_old, dim=1) * torch.softmax(logits[:, :nb_old_classes], dim=1)).sum(dim=1)

    if pseudo_soft == "soft_certain":
        mask_certain = ~mask_background
        mask_uncertain = mask_valid_pseudo & mask_background
    elif pseudo_soft == "soft_uncertain":
        mask_certain = (mask_valid_pseudo & mask_background) | (~mask_background)
        mask_uncertain = ~mask_valid_pseudo & mask_background

    loss_certain = mask_certain.float() * loss_certain
    loss_uncertain = (~mask_certain).float() * loss_uncertain

    return loss_certain + pseudo_soft_factor * loss_uncertain


class FocalLoss(nn.Module):

    def __init__(self, alpha=1, gamma=2, reduction="mean", ignore_index=255):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.ignore_index = ignore_index
        self.reduction = reduction

    def forward(self, inputs, targets,balanced_alpha=1):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', ignore_index=self.ignore_index)
        # pt = torch.exp(-ce_loss)
        pt = torch.softmax(inputs, dim=1)
        pt = torch.gather(pt, index=targets.unsqueeze(1), dim=1)
        focal_loss = self.alpha * (1 - pt)**self.gamma * ce_loss
        if self.reduction == "mean":
            return focal_loss.mean()
        elif self.reduction == "sum":
            return focal_loss.sum()
        return focal_loss


class FocalLossNew(nn.Module):

    def __init__(self, alpha=1, gamma=2, reduction="mean", ignore_index=255, index=0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.ignore_index = ignore_index
        self.reduction = reduction
        self.index = index

    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', ignore_index=self.ignore_index)
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt)**self.gamma * ce_loss

        mask_new = (targets >= self.index).float()
        focal_loss = mask_new * focal_loss + (1. - mask_new) * ce_loss

        if self.reduction == "mean":
            return focal_loss.mean()
        elif self.reduction == "sum":
            return focal_loss.sum()
        return focal_loss


class BCEWithLogitsLossWithIgnoreIndex(nn.Module):

    def __init__(self, reduction='mean', ignore_index=255):
        super().__init__()
        self.reduction = reduction
        self.ignore_index = ignore_index

    def forward(self, inputs, targets):
        # inputs of size B x C x H x W
        n_cl = torch.tensor(inputs.shape[1]).to(inputs.device)
        labels_new = torch.where(targets != self.ignore_index, targets, n_cl)
        # replace ignore with numclasses + 1 (to enable one hot and then remove it)
        targets = F.one_hot(labels_new, inputs.shape[1] + 1).float().permute(0, 3, 1, 2)
        targets = targets[:, :inputs.shape[1], :, :]  # remove 255 from 1hot
        # targets is B x C x H x W so shape[1] is C
        loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        # loss has shape B x C x H x W
        loss = loss.sum(dim=1)  # sum the contributions of the classes
        if self.reduction == 'mean':
            # if targets have only zeros, we skip them
            return torch.masked_select(loss, targets.sum(dim=1) != 0).mean()
        elif self.reduction == 'sum':
            return torch.masked_select(loss, targets.sum(dim=1) != 0).sum()
        else:
            return loss * targets.sum(dim=1)


class IcarlLoss(nn.Module):

    def __init__(self, reduction='mean', ignore_index=255, bkg=False):
        super().__init__()
        self.reduction = reduction
        self.ignore_index = ignore_index
        self.bkg = bkg

    def forward(self, inputs, targets, output_old):
        # inputs of size B x C x H x W
        n_cl = torch.tensor(inputs.shape[1]).to(inputs.device)
        labels_new = torch.where(targets != self.ignore_index, targets, n_cl)
        # replace ignore with numclasses + 1 (to enable one hot and then remove it)
        targets = F.one_hot(labels_new, inputs.shape[1] + 1).float().permute(0, 3, 1, 2)
        targets = targets[:, :inputs.shape[1], :, :]  # remove 255 from 1hot
        if self.bkg:
            targets[:, 1:output_old.shape[1], :, :] = output_old[:, 1:, :, :]
        else:
            targets[:, :output_old.shape[1], :, :] = output_old

        # targets is B x C x H x W so shape[1] is C
        loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        # loss has shape B x C x H x W
        loss = loss.sum(dim=1)  # sum the contributions of the classes
        if self.reduction == 'mean':
            # if targets have only zeros, we skip them
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:
            return loss


class UnbiasedCrossEntropy(nn.Module):

    def __init__(self, old_cl=None, reduction='mean', ignore_index=255):
        super().__init__()
        self.reduction = reduction
        self.ignore_index = ignore_index
        self.old_cl = old_cl

    def forward(self, inputs, targets, mask=None):

        old_cl = self.old_cl
        outputs = torch.zeros_like(inputs)  # B, C (1+V+N), H, W
        den = torch.logsumexp(inputs, dim=1)  # B, H, W       den of softmax
        outputs[:, 0] = torch.logsumexp(inputs[:, 0:old_cl], dim=1) - den  # B, H, W       p(O)
        outputs[:, old_cl:] = inputs[:, old_cl:] - den.unsqueeze(dim=1)  # B, N, H, W    p(N_i)

        # Following line was fixed more recently in:
        # https://github.com/fcdl94/MiB/commit/1c589833ce5c1a7446469d4602ceab2cdeac1b0e
        # and added to my repo the 04 August 2020 at 10PM
        labels = targets.clone()  # B, H, W

        labels[targets < old_cl] = 0  # just to be sure that all labels old belongs to zero

        if mask is not None:
            labels[mask] = self.ignore_index
        loss = F.nll_loss(outputs, labels, ignore_index=self.ignore_index, reduction=self.reduction)

        return loss


def nca(
    similarities,
    targets,
    loss,
    class_weights=None,
    focal_gamma=None,
    scale=1,
    margin=0.,
    exclude_pos_denominator=True,
    hinge_proxynca=False,
    memory_flags=None,
):
    """Compute AMS cross-entropy loss.

    Reference:
        * Goldberger et al.
          Neighbourhood components analysis.
          NeuriPS 2005.
        * Feng Wang et al.
          Additive Margin Softmax for Face Verification.
          Signal Processing Letters 2018.

    :param similarities: Result of cosine similarities between weights and features.
    :param targets: Sparse targets.
    :param scale: Multiplicative factor, can be learned.
    :param margin: Margin applied on the "right" (numerator) similarities.
    :param memory_flags: Flags indicating memory samples, although it could indicate
                         anything else.
    :return: A float scalar loss.
    """
    b = similarities.shape[0]
    c = similarities.shape[1]
    w = similarities.shape[-1]

    if margin > 0.:
        similarities = similarities.view(b, c, w * w)
        targets = targets.view(b * w * w)
        margins = torch.zeros_like(similarities)
        margins = margins.permute(0, 2, 1)
        margins[torch.arange(margins.shape[0]), targets, :] = margin
        margins = margins.permute(0, 2, 1)
        similarities = similarities - margin
        similarities = similarities.view(b, c, w, w)
        targets = targets.view(b, w, w)

    similarities = scale * similarities

    if exclude_pos_denominator:  # NCA-specific
        similarities = similarities - similarities.max(dim=1, keepdims=True)[0]  # Stability

        disable_pos = torch.zeros_like(similarities)
        disable_pos[torch.arange(len(similarities)),
                    targets] = similarities[torch.arange(len(similarities)), targets]

        numerator = similarities[torch.arange(similarities.shape[0]), targets]
        denominator = similarities - disable_pos

        losses = numerator - torch.log(torch.exp(denominator).sum(-1))
        if class_weights is not None:
            losses = class_weights[targets] * losses

        losses = -losses
        if hinge_proxynca:
            losses = torch.clamp(losses, min=0.)

        loss = torch.mean(losses)
        return loss

    return loss(similarities, targets)


class NCA(nn.Module):

    def __init__(self, scale=1., margin=0., ignore_index=255, reduction="mean"):
        super().__init__()
        self.ce = nn.CrossEntropyLoss(ignore_index=ignore_index, reduction=reduction)
        self.scale = scale
        self.margin = margin

    def forward(self, inputs, targets):
        return nca(inputs, targets, self.ce, scale=self.scale, margin=self.margin)


class UnbiasedNCA(nn.Module):

    def __init__(self, scale=1., margin=0., old_cl=None, reduction='mean', ignore_index=255):
        super().__init__()
        self.unce = UnbiasedCrossEntropy(old_cl, reduction, ignore_index)
        self.scale = scale
        self.margin = margin

    def forward(self, inputs, targets):
        return nca(inputs, targets, self.unce, scale=self.scale, margin=self.margin)

#
# class MyKnowledge(nn.Module):
#     def __init__(self, reduction='mean', alpha=1., kd_cil_weights=False):
#         super().__init__()
#         self.reduction = reduction
#         self.alpha = alpha
#         self.kd_cil_weights = kd_cil_weights
#         self.c = 0.5
#
#
#     def __call__(self,inputs, targets, pro_old, dl_sum, du_sum, logger):
#
#         new_class = inputs[:, -1, :, :].detach()
#         inputs = inputs.narrow(1, 0, targets.shape[1])
#         outputs_new = torch.softmax(inputs, dim=1)
#         # temp = torch.sum(inputs,dim=1, keepdim=True)
#         # temp = torch.cat([temp,new_class], dim=1)
#         # temp = torch.softmax(temp,dim=1)
#         labels = torch.softmax(targets, dim=1)
#         # labels[:, 2, :, :] = labels[:, 2, :, :] * 2.0
#         # labels[:, 1, :, :] = labels[:, 1, :, :] * 1.5
#         # weight_mask = (labels == 2).long() * self.weght_class_2
#         # weight_mask.data.masked_fill_(weight_mask==0, 1.0)
#         # print(torch.unique(labels),torch.unique(weight_mask))
#
#         pro_, dl, du = self.update_d(outputs_new=outputs_new, outputs_old=labels, p_old=pro_old)
#         dl_sum += dl
#
#         du_sum += du
#
#
#
#
#         d = 1.0 + (1.0 + self.c + du_sum) / (1.0+self.c + dl_sum)
#         d[0]  = 1.0
#         d[1] = 1.0
#         dl_sum[0] = 1.0
#         du_sum[0] = 1.0
#         dl_sum[1] = 1.0
#         du_sum[1] = 1.0
#         d_expand = d.unsqueeze(0).unsqueeze(-1).to(labels.data.device).detach().expand_as(labels)
#
#         mask_d = (torch.abs(outputs_new - labels) > pro_.unsqueeze(0).unsqueeze(-1).to(labels.data.device).detach().expand_as(labels)) * d_expand
#         # mask_d = mask_d[:, 0:4, :, :]
#         outputs = torch.log_softmax(inputs, dim=1)
#         # mask_d = d[0:4].unsqueeze(0).unsqueeze(-1).to(labels.data.device).detach()
#         # mask_d = mask_d.expand_as(outputs)
#         # d =d.detach()
#
#         # for cl_old in list(range(4)):
#         # mask_d = (labels > 0.5).long() * mask_d
#         mask_d = mask_d.masked_fill(mask_d==0, 1.0)
#
#
#         # loss = mask_d * (outputs_new - labels) **2
#         # loss = loss.mean(dim=1)
#         # outputs = torch.mean(loss)
#         loss = (outputs * labels * mask_d)
#         if self.kd_cil_weights:
#             w = -(torch.softmax(targets, dim=1) * torch.log_softmax(targets, dim=1)).sum(dim=1) + 1.0
#             loss = loss * w[:, None]
#
#         # if mask is not None:
#         #     loss = loss * mask.float()
#
#         if self.reduction == 'mean':
#             outputs = -torch.mean(loss)
#         elif self.reduction == 'sum':
#             outputs = -torch.sum(loss)
#         else:
#             outputs = -loss
#
#         # logger.info(f"p_old {pro_}")
#         pro_old = pro_
#
#         return outputs, pro_old.detach(), dl_sum.detach(), du_sum.detach(), d.detach()
#
#     def update_d(self, outputs_new, outputs_old, p_old):
#
#         # cl_map = torch.argmax(outputs_old, dim=1, keepdim=True)
#         cl_old = list(range(4))
#         p_new = torch.zeros([4, 1], dtype=torch.float32)
#         p_zero = torch.zeros([4,1],dtype=torch.float32)
#         # compute current probability for every instance
#         for cl in range(4):
#             # mask = (outputs_old[:, cl, :, :] > 0.5)
#             prob_current =  torch.abs(outputs_old[:, cl, :, :] - outputs_new[:, cl, :, :])
#             prob_current_mean = prob_current.mean()
#             if ~torch.isnan(prob_current_mean) and ~torch.isinf(prob_current_mean): p_new[cl] = prob_current_mean
#         # compute current du and dl
#         log_item = [val.item() if ~torch.isnan(val) and ~torch.isinf(val) else 0.0
#                     for val in torch.log(p_new / p_old)]
#         log_item = torch.tensor(log_item).view(p_new.shape)
#         max_item, _ = torch.max(torch.cat([p_new - p_old, p_zero], dim=1), dim=1, keepdim=True)
#         min_item, _ = torch.min(torch.cat([p_new - p_old, p_zero], dim=1), dim=1, keepdim=True)
#
#         max_item *= log_item
#         min_item *= log_item
#         max_item_sum = torch.sum(max_item, dim=0, keepdim=True) - max_item
#         min_item_sum = torch.sum(min_item, dim=0, keepdim=True) - min_item
#         dl_new = max_item + min_item_sum
#         du_new = min_item + max_item_sum
#
#         p_old = p_new.detach().clone()
#         return p_old, dl_new, du_new
#




class PairKnowledgeLoss(nn.Module):

    def __init__(self, reduction='mean', alpha=1., kd_cil_weights=False):
        super().__init__()
        self.reduction = reduction
        self.alpha = alpha
        self.kd_cil_weights = kd_cil_weights
        self.MSE = nn.MSELoss()

    def forward(self, inputs, targets,labels=None, mask=None):
        outputs = torch.tensor(0.0)
        input = inputs.narrow(1, 0, targets.shape[1])

        soft_targets = torch.softmax(targets, dim=1)
        soft_log_inputs = torch.log_softmax(input, dim=1)

        soft_inputs = torch.softmax(input, dim=1)
        soft_log_targets = torch.log_softmax(targets, dim=1)

        loss_inputs_targets = (soft_inputs.detach() * (soft_log_inputs.detach() - soft_log_targets)).mean(dim=1)
        loss_targets_inputs = (soft_targets.detach() * (soft_log_targets.detach() - soft_log_inputs)).mean(dim=1)
        outputs = torch.mean(loss_inputs_targets) + torch.mean(loss_targets_inputs)

        return outputs


class FocalKnowledgeDistillationLoss(nn.Module):

    def __init__(self, reduction='mean', alpha=1., kd_cil_weights=False):
        super().__init__()
        self.reduction = reduction
        self.alpha = alpha
        self.kd_cil_weights = kd_cil_weights
        self.MSE = nn.MSELoss()

    def forward(self, inputs, targets, mask=None):
        # inputs = inputs.narrow(1, 0, targets.shape[1])
        #
        # outputs = torch.log_softmax(inputs, dim=1)
        # labels = torch.softmax(targets * self.alpha, dim=1)
        # outputs_new = torch.softmax(inputs, dim=1)
        # loss_l1 = torch.abs(labels-outputs_new).mean()
        # loss_mse = self.MSE(labels,outputs_new)
        # novel_loss = torch.abs(labels-outputs_new).mean(dim=1)
        # outputs = torch.mean(novel_loss)

        # loss = (outputs * labels).mean(dim=1)
        # if self.kd_cil_weights:
        #     w = -(torch.softmax(targets, dim=1) * torch.log_softmax(targets, dim=1)).sum(dim=1) + 1.0
        #     loss = loss * w[:, None]
        #
        # if mask is not None:
        #     loss = loss * mask.float()
        #
        # if self.reduction == 'mean':
        #     outputs = -torch.mean(loss)
        # elif self.reduction == 'sum':
        #     outputs = -torch.sum(loss)
        # else:
        #     outputs = -loss

        inputs = inputs.narrow(1, 0, targets.shape[1])

        indexs = torch.argmax(targets, dim=1, keepdim=True)
        sources = torch.ones_like(indexs, dtype=torch.float)
        sources[indexs == 2] = 10
        sources[indexs == 1] = 10
        factors = torch.ones_like(targets)
        factors = factors.scatter(dim=1, index=indexs, src=sources)
        outputs = torch.log_softmax(inputs, dim=1)
        labels = torch.softmax(targets * self.alpha, dim=1)
        soft_outputs = torch.softmax(inputs * self.alpha, dim=1)
        factor = torch.tensor([0.9, 2, 3.0, 0.9], device=labels.device, requires_grad=False).view(1, -1, 1, 1)

        balanced = factor * ((labels - soft_outputs)) ** 2
        loss = (balanced * outputs * labels).mean(dim=1)

        if self.kd_cil_weights:
            w = -(torch.softmax(targets, dim=1) * torch.log_softmax(targets, dim=1)).sum(dim=1) + 1.0
            loss = loss * w[:, None]

        if mask is not None:
            loss = loss * mask.float()

        if self.reduction == 'mean':
            outputs = -torch.mean(loss)
        elif self.reduction == 'sum':
            outputs = -torch.sum(loss)
        else:
            outputs = -loss

        return outputs




        return outputs


class KnowledgeDistillationLoss(nn.Module):

    def __init__(self, reduction='mean', alpha=1., kd_cil_weights=False):
        super().__init__()
        self.reduction = reduction
        self.alpha = alpha
        self.kd_cil_weights = kd_cil_weights
        self.MSE = nn.MSELoss()

    def forward(self, inputs, targets, mask=None):
        # inputs = inputs.narrow(1, 0, targets.shape[1])
        #
        # outputs = torch.log_softmax(inputs, dim=1)
        # labels = torch.softmax(targets * self.alpha, dim=1)
        # outputs_new = torch.softmax(inputs, dim=1)
        # loss_l1 = torch.abs(labels-outputs_new).mean()
        # loss_mse = self.MSE(labels,outputs_new)
        # novel_loss = torch.abs(labels-outputs_new).mean(dim=1)
        # outputs = torch.mean(novel_loss)



        # loss = (outputs * labels).mean(dim=1)
        # if self.kd_cil_weights:
        #     w = -(torch.softmax(targets, dim=1) * torch.log_softmax(targets, dim=1)).sum(dim=1) + 1.0
        #     loss = loss * w[:, None]
        #
        # if mask is not None:
        #     loss = loss * mask.float()
        #
        # if self.reduction == 'mean':
        #     outputs = -torch.mean(loss)
        # elif self.reduction == 'sum':
        #     outputs = -torch.sum(loss)
        # else:
        #     outputs = -loss

        inputs = inputs.narrow(1, 0, targets.shape[1])


        indexs = torch.argmax(targets,dim=1,keepdim=True)
        sources = torch.ones_like(indexs,dtype=torch.float)
        sources[indexs==2] = 10
        sources[indexs == 1] = 10
        factors = torch.ones_like(targets)
        factors = factors.scatter(dim=1,index=indexs,src=sources)
        outputs = torch.log_softmax(inputs, dim=1)
        labels = torch.softmax(targets * self.alpha, dim=1)
        soft_outputs = torch.softmax(inputs * self.alpha, dim=1)
        factor = torch.tensor([0.9,2,3.0,0.9], device=labels.device,requires_grad=False).view(1,-1,1,1)

        balanced = factor * ((labels - soft_outputs))**2
        loss = (balanced * outputs * labels).mean(dim=1)


        if self.kd_cil_weights:
            w = -(torch.softmax(targets, dim=1) * torch.log_softmax(targets, dim=1)).sum(dim=1) + 1.0
            loss = loss * w[:, None]

        if mask is not None:
            loss = loss * mask.float()

        if self.reduction == 'mean':
            outputs = -torch.mean(loss)
        elif self.reduction == 'sum':
            outputs = -torch.sum(loss)
        else:
            outputs = -loss

        return outputs

    #loss_l1
    # 1.0 : 0.681562
    # 1.25: 0.682750
    # 1.30: 0.681893
    # 1.10: 0.682677

    #loss_mse
    # 1.00: 0.683399
    # 1.50: 0.683540


class ExcludedKnowledgeDistillationLoss(nn.Module):

    def __init__(self, reduction='mean', index_new=-1, new_reduction="gt",
                 initial_nb_classes=-1, temperature_semiold=1.0):
        super().__init__()
        self.reduction = reduction

        self.initial_nb_classes = initial_nb_classes
        self.temperature_semiold = temperature_semiold

        #assert index_new > 0, index_new
        self.index_new = index_new
        if new_reduction not in ("gt", "sum"):
            raise ValueError(f"Unknown new_reduction={new_reduction}")
        self.new_reduction = new_reduction

    def forward(self, inputs, targets, labels, mask=None):
        bs, ch_new, w, h = inputs.shape
        device = inputs.device
        labels_no_unknown = labels.clone()
        labels_no_unknown[labels_no_unknown == 255] = 0

        temperature_semiold = torch.ones(bs, self.index_new + 1, w , h).to(device)
        if self.index_new > self.initial_nb_classes:
            temperature_semiold[:, self.initial_nb_classes:self.index_new] = temperature_semiold[:, self.initial_nb_classes:self.index_new] / self.temperature_semiold

        # 1. If pixel is from new class
        new_inputs = torch.zeros(bs, self.index_new + 1, w, h).to(device)
        new_targets = torch.zeros(bs, self.index_new + 1, w, h).to(device)

        #   1.1. new_bg -> 0
        new_targets[:, 0] = 0.
        new_inputs[:, 0] = inputs[:, 0]
        #   1.2. new_old -> old_old
        new_targets[:, 1:self.index_new] = targets[:, 1:]
        new_inputs[:, 1:self.index_new] = inputs[:, 1:self.index_new]
        #   1.3. new_new GT -> old_bg
        if self.new_reduction == "gt":
            nb_pixels = bs * w * h
            new_targets[:, self.index_new] = targets[:, 0]
            tmp = inputs.view(bs, ch_new, w * h).permute(0, 2, 1).reshape(nb_pixels, ch_new)[torch.arange(nb_pixels), labels_no_unknown.view(nb_pixels)]
            tmp = tmp.view(bs, w, h)
            new_inputs[:, self.index_new] = tmp
        elif self.new_reduction == "sum":
            new_inputs[:, self.index_new] = inputs[:, self.index_new:].sum(dim=1)

        loss_new = -(torch.log_softmax(temperature_semiold * new_inputs, dim=1) * torch.softmax(temperature_semiold * new_targets, dim=1)).sum(dim=1)

        # 2. If pixel is from old class
        old_inputs = torch.zeros(bs, self.index_new + 1, w, h).to(device)
        old_targets = torch.zeros(bs, self.index_new + 1, w, h).to(device)

        #   2.1. new_bg -> old_bg
        old_targets[:, 0] = targets[:, 0]
        old_inputs[:, 0] = inputs[:, 0]
        #   2.2. new_old -> old_old
        old_targets[:, 1:self.index_new] = targets[:, 1:self.index_new]
        old_inputs[:, 1:self.index_new] = inputs[:, 1:self.index_new]
        #   2.3. new_new -> 0
        if self.new_reduction == "gt":
            old_targets[:, self.index_new] = 0.
            tmp = inputs.view(bs, ch_new, w * h).permute(0, 2, 1).reshape(nb_pixels, ch_new)[torch.arange(nb_pixels), labels_no_unknown.view(nb_pixels)]
            tmp = tmp.view(bs, w, h)
            old_inputs[:, self.index_new] = tmp
        elif self.new_reduction == "sum":
            old_inputs[:, self.index_new] = inputs[:, self.index_new:].sum(dim=1)

        loss_old = -(torch.log_softmax(temperature_semiold * old_inputs, dim=1) * torch.softmax(temperature_semiold * old_targets, dim=1)).sum(dim=1)

        mask_new = (labels >= self.index_new) & (labels < 255)
        mask_old = labels < self.index_new
        loss = (mask_new.float() * loss_new) + (mask_old.float() * loss_old)

        if self.reduction == 'mean':
            return torch.mean(loss)
        elif self.reduction == 'sum':
            return torch.sum(loss)
        return loss


class BCESigmoid(nn.Module):
    def __init__(self, reduction="mean", alpha=1.0, shape="trim"):
        super().__init__()
        self.reduction = reduction
        self.alpha = alpha
        self.shape = shape

    def forward(self, inputs, targets, mask=None):
        nb_old_classes = targets.shape[1]
        if self.shape == "trim":
            inputs = inputs[:, :nb_old_classes]
        elif self.shape == "sum":
            inputs[:, 0] = inputs[:, nb_old_classes:].sum(dim=1)
            inputs = inputs[:, :nb_old_classes]
        else:
            raise ValueError(f"Unknown parameter to handle shape = {self.shape}.")

        inputs = torch.sigmoid(self.alpha * inputs)
        targets = torch.sigmoid(self.alpha * targets)

        loss = F.binary_cross_entropy(inputs, targets, reduction=self.reduction)
        if mask is not None:
            loss = loss * mask.float()

        if self.reduction == 'mean':
            return torch.mean(loss)
        elif self.reduction == 'sum':
            return torch.sum(loss)
        return loss


class UnbiasedKnowledgeDistillationLoss(nn.Module):

    def __init__(self, reduction='mean', alpha=1.):
        super().__init__()
        self.reduction = reduction
        self.alpha = alpha

    def forward(self, inputs, targets, mask=None):

        new_cl = inputs.shape[1] - targets.shape[1]

        targets = targets * self.alpha

        new_bkg_idx = torch.tensor([0] + [x for x in range(targets.shape[1], inputs.shape[1])]).to(
            inputs.device
        )

        den = torch.logsumexp(inputs, dim=1)  # B, H, W
        outputs_no_bgk = inputs[:, 1:-new_cl] - den.unsqueeze(dim=1)  # B, OLD_CL, H, W
        outputs_bkg = torch.logsumexp(
            torch.index_select(inputs, index=new_bkg_idx, dim=1), dim=1
        ) - den  # B, H, W

        labels = torch.softmax(targets, dim=1)  # B, BKG + OLD_CL, H, W

        soft_den = torch.softmax(inputs, dim=1)
        factor = 1.0
        balanced_bkg = factor * (labels[:, 0] - soft_den[:, 0])**2
        balanced_no_bkg = factor * (labels[:, 1:] - soft_den[:, 1:targets.shape[1]])**2
        # make the average on the classes 1/n_cl \sum{c=1..n_cl} L_c
        loss = 3 * (labels[:, 0] * outputs_bkg*balanced_bkg +
                (labels[:, 1:] * outputs_no_bgk * balanced_no_bkg ).sum(dim=1)) / targets.shape[1]

        if mask is not None:
            loss = loss * mask.float()

        if self.reduction == 'mean':
            outputs = -torch.mean(loss)
        elif self.reduction == 'sum':
            outputs = -torch.sum(loss)
        else:
            outputs = -loss

        return outputs
# Contrastive Learning loss defined in SDR: https://arxiv.org/abs/2103.06342
class FeaturesClusteringSeparationLoss(nn.Module):
    def __init__(self, device, reduction='mean', alpha=1., num_classes=0, logdir=None, feat_dim=2048,
                 lfc_L2normalized=False, lfc_nobgr=False, lfc_sep_clust=0., lfc_sep_clust_ison_proto=False,
                 orth_sep=False, lfc_orth_maxonly=False):
        super().__init__()
        self.reduction = reduction
        self.alpha = alpha
        self.num_classes = num_classes
        self.device = device
        self.logdir = logdir
        self.lfc_L2normalized = lfc_L2normalized
        self.lfc_nobgr = lfc_nobgr
        self.lfc_sep_clust = lfc_sep_clust
        self.lfc_sep_clust_ison_proto = lfc_sep_clust_ison_proto
        self.orth_sep = orth_sep
        self.lfc_orth_maxonly = lfc_orth_maxonly
        self.feat_dim = feat_dim

    def _visualize_with_tSNE(self, tSNE_path_to_save, features, labels_down, epoch=0, train_step=0, step=0):
        # visualization with t-SNE from sklearn (very slow, can improve 1000x with t-SNE for CUDA
        # or x100 with t-SNE w multiprocessing
        # X_embedded = TSNE(n_components=2).fit_transform(features.detach().view(-1, features.shape[1]))
        classes = {
            0: 'background',
            1: 'aeroplane',
            2: 'bicycle',
            3: 'bird',
            4: 'boat',
            5: 'bottle',
            6: 'bus',
            7: 'car',
            8: 'cat',
            9: 'chair',
            10: 'cow',
            11: 'diningtable',
            12: 'dog',
            13: 'horse',
            14: 'motorbike',
            15: 'person',
            16: 'pottedplant',
            17: 'sheep',
            18: 'sofa',
            19: 'train',
            20: 'tvmonitor'
        }
        tsne = MulticoreTSNE(n_jobs=4)

        features = features.detach().view(-1, features.shape[1]).cpu()
        labels_down = labels_down.view(-1)
        features_nobgr = features[labels_down != 0, :]
        labels_down = labels_down[labels_down != 0]

        features_nobgr = F.normalize(features_nobgr, p=2, dim=0)

        X_embedded_multicore = tsne.fit_transform(features_nobgr)

        plt.figure()
        sns.scatterplot(X_embedded_multicore[:, 0], X_embedded_multicore[:, 1], hue=[classes[x] for x in labels_down.view(-1).cpu().numpy()],
                        legend='full', palette=sns.color_palette("bright", torch.unique(labels_down).size(0)))
        plt.savefig(f"{tSNE_path_to_save}/step_{step}_epoch_{epoch}_{train_step}_tSNE.png")
        plt.close()

    def forward(self, labels, outputs, features_layers, train_step=0, step=0, epoch=0, val=False, mask=None, prototypes=None,
                incremental_step=None):
        loss_features_clustering = torch.tensor(0., device=self.device)
        loss_separationclustering = torch.tensor(0., device=self.device)
        layers_index = [4]
        features = features_layers[4]

        if (not val) and (incremental_step != 0):
            labels = labels.unsqueeze(dim=1)

            # for idx, features in enumerate(prototypes):
            labels_down = (F.interpolate(input=labels.double(), size=(features_layers[layers_index[0]].shape[2], features_layers[layers_index[0]].shape[3]), mode='nearest')).long()
            cl_present = torch.unique(input=labels_down)


            cl_present = cl_present[1:]

            if cl_present[-1] == 255:
                cl_present = cl_present[:-1]

            features_local_mean = torch.zeros([self.num_classes, self.feat_dim], device=self.device)

            for cl in cl_present:

                features_cl = features[(labels_down == cl).expand(-1, features.shape[1], -1, -1)].view(features.shape[1], -1)

                # L2 normalization of the features
                if self.lfc_L2normalized:
                    features_cl = F.normalize(features_cl, p=2, dim=0)
                    prototypes = F.normalize(prototypes, p=2, dim=0)

                features_local_mean[cl] = torch.mean(features_cl, dim=-1)

                loss_to_use = nn.MSELoss()
                loss_features_clustering += loss_to_use(features_cl, prototypes[cl].unsqueeze(1).expand(-1, features_cl.shape[1]))

                loss_features_clustering /= (cl_present.shape[0])

            if self.lfc_sep_clust > 0.:
                features_local_mean_reduced = features_local_mean[cl_present,:]  # remove zero rows
                features_local_mean_reduced = features[cl_present, :]
                if not self.orth_sep:
                    if not self.lfc_sep_clust_ison_proto:
                        inv_pairwise_D = 1 / torch.cdist(features_local_mean_reduced.unsqueeze(dim=0),
                                                         features_local_mean_reduced.unsqueeze(dim=0)).squeeze()
                    else:
                        inv_pairwise_D = 1 / torch.cdist(features_local_mean_reduced.unsqueeze(dim=0),
                                                         prototypes.detach()[features.abs().sum(dim=-1) != 0].unsqueeze(dim=0)).squeeze()

                    loss_separationclustering_temp = inv_pairwise_D[~torch.isinf(inv_pairwise_D)].mean()
                    if ~torch.isnan(loss_separationclustering_temp): loss_separationclustering = loss_separationclustering_temp +loss_separationclustering
                else:
                    # features in features_local_mean_reduced to be orthogonal to those in self if not belongin to the same class

                    vectorial_products = (torch.mm(prototypes, features_local_mean_reduced.T)).squeeze()
                    vectorial_products[cl_present, range(0, cl_present.shape[0])] = 0

                    if self.lfc_orth_maxonly:
                        loss_separationclustering = torch.max(vectorial_products)
                    else:
                        loss_separationclustering = torch.sum(vectorial_products) / \
                                                    (vectorial_products.shape[0]*vectorial_products.shape[1] -
                                                     cl_present.shape[0])

        # visualize every epoch
        # img_path_to_save = self.logdir
        # if not val and not(os.path.exists(f"{img_path_to_save}/step_{step}_epoch_{epoch}_{train_step}_tSNE.png"))and train_step % 250 == 0 and (incremental_step != 0):
        #     os.makedirs(img_path_to_save, exist_ok=True)
        #     self._visualize_with_tSNE(img_path_to_save, features, labels_down, epoch, train_step, step)
        return loss_separationclustering


# Prototypes Matching loss defined in SDR: https://arxiv.org/abs/2103.06342
class DistillationEncoderPrototypesLoss(nn.Module):
    def __init__(self, device, num_classes, mask=False):
        super().__init__()
        self.mask = mask
        self.num_classes = num_classes
        self.device = device

    def _compute_mask_old_classes(self, features, labels, classes_old):
        labels = labels.unsqueeze(dim=1)
        labels_down = (F.interpolate(input=labels.double(), size=(features.shape[2], features.shape[3]), mode='nearest'))
        mask = labels_down < classes_old
        return mask

    def forward(self, outputs, outputs_old, features_layers, features_old, labels, classes_old, incremental_step,
                sequential=False, overlapped=False, loss_de_prototypes_sumafter=False, val=False, prototypes=None,
                count_features=None, prototype_memory=None):
        layers_index = [4]

        clusting = torch.tensor(0., device=self.device)
        seperating = torch.tensor(0., device=self.device)

        labels_output = torch.argmax(outputs,dim=1,keepdim=True)

        MSEloss_to_use = nn.MSELoss()

        labels = labels.unsqueeze(dim=1)
        cl_new_present = torch.unique(labels)
        cl_new_present = cl_new_present[1:]


        labels_mask = (labels.eq(0)).long() # 'background'
        pseudolabel_old = torch.argmax(outputs_old,dim=1, keepdim=True) * labels_mask
        for idx, layer in enumerate(layers_index):
            features = features_layers[layer]
            labels_down = (F.interpolate(input=labels.double(), size=(features.shape[2], features.shape[3]), mode='nearest')).long()
            labels_output = (F.interpolate(input=labels_output.double(), size=(features.shape[2], features.shape[3]), mode='nearest')).long()
            labels_down_bgr_mask = (labels_down == 0).long()
            b, c, h, w = features.shape
            if self.num_classes is not None and not val:

                if incremental_step != 0:
                    if sequential:  # we can directly use the current groundtruth masked to consider only previous classes.
                        pseudolabel_old_down = labels_down * (labels_down < classes_old).long()
                    else:  # if disjoint or overlapped: old classes are bgr in new images, hence we rely on previous model output
                        outputs_old = torch.argmax(outputs_old, dim=1, keepdim=True)    # TODO: investigate with other functions (entropy,...)
                        outputs_old_down = (F.interpolate(input=outputs_old.double(), size=(features.shape[2], features.shape[3]), mode='nearest')).long()
                        pseudolabel_old_down = outputs_old_down * labels_down_bgr_mask.long()

                    pseudolabel_old_down = pseudolabel_old_down * labels_down.eq(0)

                    pseudolabel_old_down = (F.interpolate(input=pseudolabel_old.double(), size=(features.shape[2], features.shape[3]),
                                  mode='nearest')).long()
                    cl_old_present = torch.unique(input=pseudolabel_old_down).long()
                    if cl_old_present[0] == 0:
                        cl_old_present = cl_old_present[1:]

                    pad_size = prototype_memory.shape[1] - c
                    if pad_size != 0:
                        pad_zero = torch.zeros([b, pad_size, h, w], device=self.device)
                        features = torch.cat([features, pad_zero], dim=1)

                    for cl in cl_old_present:
                        prototype = prototypes.detach()[idx, cl]
                        current_features = features[(pseudolabel_old_down == cl).expand_as(features)].view(-1, features.shape[1])
                        if  loss_de_prototypes_sumafter:
                            current_proto = torch.mean(current_features, dim=0)
                            clusting += MSEloss_to_use(current_proto, prototype) / cl_old_present.shape[0]

                        else:
                            for f in range(current_features.size(0)):
                                clusting += MSEloss_to_use(current_features[f, :], prototype) / (current_features.shape[0])



        return clusting + seperating, prototype_memory