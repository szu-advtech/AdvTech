import torch

def update_d(outputs_new, outputs_old, p_old):

    cl_map = torch.argmax(outputs_old, dim=1, keepdim=True)
    p_new = torch.zeros([5, 1], dtype=torch.float32)
    du_new = torch.zeros([5, 1], dtype=torch.float32)
    dl_new = torch.zeros([5, 1], dtype=torch.float32)

    # compute current probability for every instance
    for cl in range(5):
        cl_piexl_mask = (cl_map == cl).long()
        prob_current = outputs_new[:,cl,:,:] * cl_piexl_mask
        prob_current_mean = prob_current.sum() / cl_piexl_mask.sum()
        if ~torch.isnan(prob_current_mean) and ~torch.isinf(prob_current_mean) : p_new[cl] = prob_current_mean

    # compute current du and dl
    log_item = [val.item() if ~torch.isnan(val) and ~torch.isinf(val) else 0.0
                for val in  torch.log( p_new / p_old)]
    log_item = torch.tensor(log_item).view(p_new.shape)
    max_item, _ = torch.max(torch.cat([p_new - p_old, p_new], dim=1), dim=1, keepdim=True)
    min_item, _ = torch.min(torch.cat([p_new - p_old, p_new], dim=1), dim=1, keepdim=True)


    max_item *= log_item
    min_item *= log_item
    max_item_sum = torch.sum(max_item, dim=0, keepdim=True) - max_item
    min_item_sum = torch.sum(min_item, dim=0, keepdim=True) - min_item
    dl_new = max_item + min_item_sum
    du_new = min_item + max_item_sum

    return p_new, dl_new, du_new


