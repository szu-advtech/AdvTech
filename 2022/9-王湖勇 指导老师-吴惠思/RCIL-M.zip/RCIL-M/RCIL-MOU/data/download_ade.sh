#!/usr/bin/env bash

# use this script in the destination folder.

wget http://data.csail.mit.edu/places/ADEchallenge/ADEChallengeData2016.zip
unzip ADEChallengeData2016.zip